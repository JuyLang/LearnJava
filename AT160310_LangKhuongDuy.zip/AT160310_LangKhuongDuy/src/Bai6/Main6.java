/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai6;

/**
 *
 * @author langk
 */
public class Main6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        SoPhuc p1 = new SoPhuc();
        SoPhuc p2 = new SoPhuc();
        SoPhuc cong;
        SoPhuc hieu;
        SoPhuc chia;
        SoPhuc nghichDao;
        
        p1.nhap(sc);
        p2.nhap(sc);
        System.out.println("So phuc thu nhat");
        p1.print();
        System.out.println("So phuc thu hai");
        p2.print();
        cong = p1.cong(p2);
        hieu = p1.hieu(p2);
        chia = p1.chia(p2);
        nghichDao = p1.nghichDao();
        System.out.println("tong 2 so phuc");
        cong.print();
        System.out.println("hieu 2 so phuc");
        hieu.print();
        System.out.println("thuong 2 so phuc");
        chia.print();
        System.out.println("nghich dao so thu nhat ");
        nghichDao.print();
        
        System.out.println("so thu nhat " + p1.soSanhBang(p2) + " so thu hai");
        p1.lonHon(p2);
        p1.nhoHon(p2);
    
    }
    
}
