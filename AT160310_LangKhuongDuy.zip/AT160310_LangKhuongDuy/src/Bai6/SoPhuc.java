/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai6;

import java.util.Scanner;

/**
 *
 * @author langk
 */
public class SoPhuc {
     private int thuc;
    private int ao;

    public SoPhuc() {
        thuc = 0;
        ao = 0;
    }

    public void nhap(Scanner sc) {
        System.out.print("Nhap vao phan thuc: ");
        thuc = sc.nextInt();
        System.out.print("Nhap vao phan ao: ");
        ao = sc.nextInt();
    }

    public void print() {
        System.out.println(thuc + " + " + ao + "i");
    }

    public SoPhuc cong(SoPhuc p2) {
        SoPhuc pTong = new SoPhuc();
        pTong.thuc = thuc + p2.thuc;
        pTong.ao = ao + p2.ao;
        return pTong;
    }

    public SoPhuc hieu(SoPhuc p2) {
        SoPhuc pHieu = new SoPhuc();
        pHieu.thuc = thuc + p2.thuc;
        pHieu.ao = ao + p2.ao;
        return pHieu;
    }

    public SoPhuc chia(SoPhuc p2) {
        SoPhuc pChia = new SoPhuc();
        pChia.thuc = ((thuc * p2.thuc) + (ao * p2.ao)) / ((p2.thuc * p2.thuc)
                + (p2.ao * p2.ao));
        pChia.ao = -((thuc * p2.ao) - (ao * p2.thuc)) / ((p2.thuc * p2.thuc)
                + (p2.ao * p2.ao));

        return pChia;
    }

    public SoPhuc nghichDao() {
        SoPhuc pNghichDao = new SoPhuc();
        pNghichDao.thuc = thuc * (1 / ((thuc * thuc) + (ao * ao)));
        pNghichDao.ao = -ao * (1 / ((thuc * thuc) + (ao * ao)));

        return pNghichDao;
    }

    public String soSanhBang(SoPhuc p2) {
        if (thuc == p2.thuc && ao == p2.ao) {
            return "bang";
        }
        return "khong bang";
    }

    public void lonHon(SoPhuc p2) {
        System.out.println("ko so sanh dc 2 so phuc khi ko bang nhau");
    }

    public void nhoHon(SoPhuc p2) {
        System.out.println("ko so sanh dc 2 so phuc khi ko bang nhau");
    }
}
