/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai7;

import java.util.Scanner;

/**
 *
 * @author langk
 */
public class PhanSo {
    private int tu;
    private int mau;

    public PhanSo() {
        tu = 0;
        mau = 1;
    }

    public PhanSo(int ts, int ms) {
        this.tu = ts;
        this.mau = ms;
    }

    public void nhap(Scanner sc) {
        System.out.print("Nhap vao phan tu: ");
        tu = sc.nextInt();
        System.out.print("Nhap vao phan mau: ");
        mau = sc.nextInt();
    }

    public void print() {
        System.out.println(tu + " / " + mau);
    }

    public PhanSo cong(PhanSo p2) {
        PhanSo pTong = new PhanSo();
        pTong.mau = mau * p2.mau;
        pTong.tu = tu * p2.mau + p2.tu * mau;

        return toiGian(pTong);
    }

    public PhanSo hieu(PhanSo p2) {
        PhanSo pHieu = new PhanSo();
        pHieu.mau = mau * p2.mau;
        pHieu.tu = tu * p2.mau - p2.tu * mau;

        return toiGian(pHieu);
    }

    public PhanSo nhan(PhanSo p2) {
        PhanSo pNhan = new PhanSo();
        pNhan.mau = mau * p2.mau;
        pNhan.tu = tu * p2.tu;

        return toiGian(pNhan);
    }

    public PhanSo chia(PhanSo p2) {
        PhanSo pChia = new PhanSo();
        pChia.tu = tu * p2.mau;
        pChia.mau = mau * p2.tu;

        return toiGian(pChia);
    }

    public PhanSo nghichDao() {
        PhanSo pNghichDao = new PhanSo();
        pNghichDao.tu = mau;
        pNghichDao.mau = tu;

        return toiGian(pNghichDao);
    }

    public PhanSo doiDau() {
        PhanSo pDoiDau = new PhanSo();
        pDoiDau.mau = mau;
        pDoiDau.tu = tu * (-1);

        return toiGian(pDoiDau);
    }

    public PhanSo toiGian(PhanSo p2) {
        PhanSo pToiGian = new PhanSo();
        int a = Math.abs(p2.tu);
        int b = Math.abs(p2.mau);
        int r = 0;
        while (b > 0) {
            r = a % b;
            a = b;
            b = r;
        }

        pToiGian.mau = p2.mau / a;
        pToiGian.tu = p2.tu / a;

        return pToiGian;
    }

    public String soSanhBang(PhanSo p2) {
        if (tu * p2.mau == p2.tu * mau) {
            return "bang";
        }
        return "khong bang";
    }

    public String lonHon(PhanSo p2) {
        if (tu * p2.mau > p2.tu * mau) {
            return "lon hon";
        }
        return "khong lon hon";
    }

    public String nhoHon(PhanSo p2) {
        if (tu * p2.mau < p2.tu * mau) {
            return "nho hon";
        }
        return "khong nho hon";
    }
}
