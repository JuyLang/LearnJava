/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de07;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author langk
 */
public class QuanLy {
    private ArrayList<Object> list;

    public QuanLy(int n) {
        list = new ArrayList<>(n);
    }
    
    public void nhap(){
        Scanner input = new Scanner(System.in);
        boolean check = true;
        while(check==true){
            System.out.println("Bạn muốn thêm sinh viên khối nào vào danh sách");
            System.out.print("1. Thí sinh Khối A");
            System.out.print("2. Thí sinh Khối C");
            System.out.print("Bất kỳ - Không nhập");
            int n = input.nextInt();
            switch (n) {
                case 1:
                    ThiSinhKhoiA tsA = new ThiSinhKhoiA();
                    tsA.nhap();
                    list.add(tsA);
                    break;
                case 2:
                    ThiSinhKhoiB tsB = new ThiSinhKhoiB();
                    tsB.nhap();
                    list.add(tsB);
                    break;
                default:
                    System.out.println("Không hợp lệ");
                    check = false;
                    break;
                    
            }
        }              
    }
    
    public void input(){
        list.forEach((x) -> {
            System.out.println(x);
        });
    }
   
}
